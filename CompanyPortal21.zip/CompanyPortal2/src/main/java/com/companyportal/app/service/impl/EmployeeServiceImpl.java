package com.companyportal.app.service.impl;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.companyportal.app.dao.EmployeeDao;
import com.companyportal.app.entity.Employee;
import com.companyportal.app.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService{

	private static int count=1;
	
	@Autowired
	private EmployeeDao employeeDao;
	
	@Override
	public void saveEmployeeData(Employee employee) {
		employee.setEmployeeId(count++);
		
		employeeDao.saveEmployeeData(employee);
	}

	@Override
	public List<Employee> getEmployeesData() {
		
		return employeeDao.getEmployeesData();
	}

	@Override
	public Employee searchEmployeeByEno(int empNo) {
		// TODO Auto-generated method stub
		 return null;
		
	}

	@Override
	public void updateEmployee(Employee e, Integer empNo) {
		// TODO Auto-generated method stub
		 employeeDao.updateEmployee(e,empNo);
	}

	
	@Override
	public void deleteEmployee(Integer empNo) {
		// TODO Auto-generated method stub
		employeeDao.deleteEmployee(empNo);
	}
	

	@Override
	public List<Employee> searchEmployeeByName(String employeeName) {
		// TODO Auto-generated method stub
		return employeeDao.searchEmployeeByName(employeeName);
	}

	
}
